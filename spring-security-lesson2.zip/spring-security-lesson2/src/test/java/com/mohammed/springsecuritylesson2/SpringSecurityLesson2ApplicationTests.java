package com.mohammed.springsecuritylesson2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityLesson2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
